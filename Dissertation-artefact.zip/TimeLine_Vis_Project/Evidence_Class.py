from dataclasses import dataclass

#this class takes and stores OS information, below are more classes all following similar strcutres
@dataclass
class OsInfo:
    processor_architecture: str
    operating_system_name: str
    install_date: str
    name: str
    owner: str
    path: str
    product_id: str
    temporary_files_directory: str
    source_file: str
    tags: str

@dataclass
class Bookmark:
    url: str
    title: str
    date_created: str
    program: str
    domain: str
    source_file: str
    tags: str

@dataclass
class WebCookie:
    url: str
    date_time: str
    name: str
    value: str
    program: str
    date_created: str
    domain: str
    source_file: str
    tags: str

@dataclass
class EmailMessage:
    email_to: str
    email_from: str
    subject: str
    date_sent: str
    date_received: str
    path: str
    email_cc:str
    email_bcc:str
    message_id:str
    has_attachment:str
    header:str
    message:str
    message_attachment:str
    thread_id:str
    tags: str

@dataclass
class ProgramData:
    program: str
    associated_artifact: str
    date_time: str
    count: int
    comment: str
    path: str
    tags:str

@dataclass
class AccountEmails:
    review_status:str
    email_id:str
    tags:str

@dataclass
class DataStorageUsed:
    description:str
    source_file:str
    tags:str

@dataclass
class InstalledPrograms:
    program_name:str
    installed_datetime:str
    source_file:str
    tags:str

@dataclass
class RecentDocuments:
    path:str
    datetime:str
    comment:str
    name:str
    program_name:str
    value:str
    source_file:str
    tags:str

@dataclass
class EXIFMetadata:
    date_taken:str
    device_manufacturer:str
    device_model:str
    latitude:str
    longitude:str
    altitude:str
    source_file:str
    tags:str

@dataclass
class ShellBags:
    date_accessed:str
    date_created:str
    date_modified:str
    key:str
    last_write:str
    path:str
    source_file:str
    tags:str

@dataclass
class USBAttachedDevice:
    device_make:str
    device_model:str
    device_id:str
    datetime:str
    source_file:str
    tags:str

@dataclass
class WebDownloads:
    destination:str
    source_url:str
    date_accessed:str
    program:str
    comment:str
    domain:str
    source_file:str
    tags:str

@dataclass
class WebHistory:
    url:str
    date_accessed:str
    referrer:str
    title:str
    program:str
    url_domain:str
    domain:str
    username:str
    source_file:str
    tags:str



#metadata has mulitiple dates which could be useful but could also contain repeats. Same approach as shellbags,
#user content suspected (could be used for analysis later but not needed right now for visualisation)
#extension mismatch detected, (could be used for analysis later but not needed right now for visualisation)
#tagged files not needed
#tagged results not needed

