import tkinter as tk
from tkinter import simpledialog
from datetime import datetime, timedelta
from tkinter import messagebox, filedialog
from datetime import datetime
from tkcalendar import Calendar
from functools import partial

from Evidence_Class import OsInfo
#from Gather_data import update_os_info_from_excel, update_bookmarks_from_excel, update_WebCookie_from_excel, update_email_from_excel, update_programData_from_excel, update_installedPrograms_from_excel, update_accountEmails, update_dataStrorageUsed, update_recentDocuments_from_excel, update_exifData, update_shellBags_from_excel
from Get_Multi import set_multi
from Get_heatmap import get_heatmap_colour
from Get_colorCode import return_color
#import Evidence_Class as ec

import time #for testing

from Input_data_source import input_datasource

#file path, soon to be changable
file_path = r'C:\Users\cvdon\Documents\Uni Work\Year 4\DIssertation - Python\JD.xlsx'


#instances of the data strcutures.
os_info = OsInfo("", "", "", "", "", "", "", "", "", "")
bookmarks = []
webcookies = []
emails = []
programs = []
installedprograms = []
recentdocuments = []
shellbags = []
usbattaches = []
webdownloads = []
webhistories = []

global_multiplier = 0.0001 #changable
num_segments = 75  #changable
evidence_type = {}
filtered_evidence_tuple = []
had_ev_been_filtered = False
clustersEnabled = True

class Timeline(tk.Tk):

    #this func creates items of the GUI before rendering the timeline. Addtionally it fills up a list to subsitute for the lack of
    #data extraction from actual test files.
    def __init__(self):

        def select_file():
            """open file explorer and allow users to select file"""
            #fileEx = tk.Tk()
            #fileEx.withdraw #hide the root window
            file_path = filedialog.askopenfilename(title="Select the CSV data source")

            if file_path:
                start_time = time.time()
                input_datasource(self, os_info, bookmarks, webcookies, emails, programs, installedprograms, recentdocuments, shellbags, usbattaches, webdownloads, webhistories, file_path)
                self.append_canvas()
                end_time = time.time()
                print(f"The time is has take: {end_time-start_time:.6f} seconds")
            else:
                print("No file found")
            
            return

        def clear_data_sources():
            os_info = OsInfo("", "", "", "", "", "", "", "", "", "")
            bookmarks.clear()
            webcookies.clear()
            emails.clear()
            programs.clear()
            installedprograms.clear()
            recentdocuments.clear()
            shellbags.clear()

            self.timeline_list.clear()
            self.append_canvas()

        super().__init__()
        self.columnconfigure(0, weight=1)  #allows the column to expand
        self.title('ChronoTale')
        self.iconbitmap(r'forensic.ico')

        self.geometry('800x600')  #sets a default filter_ev_type_box size
        self.minsize(800, 600) #minimum size allowed
        self.attributes('-fullscreen', True)

        self.rowconfigure(0, weight=1, minsize=int(self.winfo_screenheight()*0.10))
        self.rowconfigure(1, weight=1, minsize=int(self.winfo_screenheight()*0.90))
        #self.rowconfigure(1, weight=1, minsize=int(self.winfo_screenheight()*0.20))

        #create a top frame instance for buttons
        self.top_frame = tk.Canvas(self, bg="lightgray", bd=0, highlightthickness=0)
        self.top_frame.grid(row=0, column=0, sticky='nsew')

        #create title for application
        title_label = tk.Label(self.top_frame, text="ChronoTale", font=('Arial', 20, 'bold'), bg='lightgray')
        title_label.pack(side="top", padx=10)
        
        #creates the canvas and allow it to expand, on the bottom row
        self.timeline_canvas = tk.Canvas(self, bg='white', bd=0, highlightthickness=0)
        self.timeline_canvas.grid(row=1, column=0, sticky='nsew')

        #creates filter buttons
        self.filter_button = tk.Button(self.top_frame, text="Filter Dates", command=self.open_filter_window)
        self.filter_button.pack(side="left", padx=10)

        #creates a label to display current filter date
        self.current_filter_label = tk.Label(self.top_frame, text="N/A", font=('Arial', 14), bg="lightgray")
        self.current_filter_label.pack(side="left")

        #creates an instance of a button to clear the filter
        self.clear_filter_button = tk.Button(self.top_frame, text="Clear Filter", command=self.clear_filter)
        self.clear_filter_button.pack(side="left", padx=10)

        #create and set muli buttons
        self.muli_button = tk.Button(self.top_frame, text="Multiplyer", command=self.get_multiplier)
        self.muli_button.pack(side="left", padx=10)

        #create a button to input data sources
        self.inputdata_source = tk.Button(self.top_frame, text="Input Data Source", command=select_file)
        self.inputdata_source.pack(side="left", padx=10)

        #button to clear data
        self.clear_data_sources = tk.Button(self.top_frame, text="Clear Data", command=clear_data_sources)
        self.clear_data_sources.pack(side='left', padx=10)

        self.evidence_filter_btn = tk.Button(self.top_frame, text="Filter Evidence Type", command=self.select_filter_evidence)
        self.evidence_filter_btn.pack(side='left', padx=10)

        self.clusterEnable_btn = tk.Button(self.top_frame, text="Enabe/Disable CLusters", command=self.enable_disable_cluster)#functions)
        self.clusterEnable_btn.pack(side="left", padx=10)

        self.refresh = tk.Button(self.top_frame, text="Refresh", command=self.refresh)
        self.refresh.pack(side="left", padx=10)

       #create a right-aligned box in the top frame to display key chart
        self.right_box = tk.Frame(self.top_frame, bg="darkgray", width=100, height=100)
        self.right_box.place(relx=1, rely=0.0, anchor="ne")

        #define colors and labels for each row.
        legend_items = [
            ("Dark Blue", "Website Activity"),
            ("Orange", "Documents"),
            ("Red", "Email activity"),
            ("Dark Green", "Programs"),
            ("Purple", "USB attached"),
            ("Black", "Registry"),
        ]

        #create a list to hold the data
        row_frame = tk.Frame(self.right_box, bg="darkgray")
        row_frame.pack(anchor="w", padx=10, pady=2)

        #loop through and create each dot and the name beside, inside top right box
        for index, (color, text) in enumerate(legend_items):

            #create a canvas for the dot and draw
            dot_canvas = tk.Canvas(row_frame, width=10, height=10, bg="darkgray", highlightthickness=0)
            dot_canvas.pack(side="left", padx=5)
            dot_canvas.create_oval(2, 2, 10, 10, fill=color, outline=color)
            #label for color next to dot
            label = tk.Label(row_frame, text=text, font=("Arial", 10), bg="darkgray", fg="white")
            label.pack(side="left")

            #add a comma after the first dot-word pair
            if (index + 1) % 2 == 0: 
                row_frame = tk.Frame(self.right_box, bg="darkgray")
                row_frame.pack(anchor="w", padx=10, pady=2)

        #initialize filters
        self.filter_start = None
        self.filter_end = None

          #create a function to zoom in and out of the current timline
        self.timeline_canvas.bind("<MouseWheel>", self.zoom_in_out)

        #bind the configure event to adjust the canvas after each mousewheel movement
        self.timeline_canvas.bind("<Configure>", self.append_canvas)

        #functions to change segment sizes based on  + & -
        self.timeline_canvas.bind("<plus>", self.change_segment_size)
        self.timeline_canvas.bind("<minus>", self.change_segment_size)
        self.timeline_canvas.focus_set()


        #timeline events - empty list to populate
        self.timeline_list = [
        ]


        #sort the timeline list by date using lambda
        self.timeline_list.sort(key=lambda x: x[0])

#######################  Function for interactive zooming  #######################################################

    #this func is responsible for for taking the mousewheel input and detemrining wheather to render the canvas zoomed in or out
    def zoom_in_out(self, event):
        #zoom in/out the timeline based on mouse wheel movement and mouse position.
        if not self.timeline_list or len(self.timeline_list) < 2:
            return  #if less than two events then return as you should not need to zoom in further when only two events remain

        #ensure filter_start and filter_end are inistialzed
        if self.filter_start is None or self.filter_end is None:
            #initialize to the full range of the timeline if no filter is set
            filtered_list = [dt for dt, _, extra in self.timeline_list]
            filtered_list.sort()
            self.filter_start = filtered_list[0]
            self.filter_end = filtered_list[-1]

        #get mouse x position on the canvas (Further investigating)
        mouse_x = self.timeline_canvas.canvasx(event.x)
        canvas_width = self.timeline_canvas.winfo_width() - 250  #change for padding on both sides
        effective_width = canvas_width - 250 #padding of 125 pixels on both sides
     
        #filtered dates
        filtered_list = [dt for dt, _, extra in self.timeline_list]
        filtered_list.sort()
        first_datetime = filtered_list[0]
        last_datetime = filtered_list[-1]

        #calculate total seconds for the current timeline range
        total_seconds = (last_datetime - first_datetime).total_seconds()
        
        #determine the amount to adjust based on mouse position (for example far left means only take time away from filter_end)
        adjustment_seconds = total_seconds * global_multiplier
        #0.0001 #(can adjust to set how much it zooms in/out by based on each mousewheel scroll)
        new_start = self.filter_start
        new_end = self.filter_end

        #calculate section boundaries to determine how much to add or minus from start and end date
        section_width = effective_width / 3
        section_boundaries = [i * section_width for i in range(1, 3)]  #3 sections boundaries in total

        #adjust filters based on mouse position
        if mouse_x < section_boundaries[0]:  #first section (minus/add seconds from end/start filter)
            if event.delta > 0:  #Zoom in
                new_end -= timedelta(seconds=adjustment_seconds)  #shrink to filter
            else:  #Zoom out
                new_end += timedelta(seconds=adjustment_seconds)  #expand to filter

        elif mouse_x < section_boundaries[1]:  #second section
            if event.delta > 0:  #Zoom in
                new_start += timedelta(seconds=adjustment_seconds / 2)  #slightly shrink from start filter
                new_end -= timedelta(seconds=adjustment_seconds / 2)  #shrink to end filter more
            else:  #Zoom out
                new_start -= timedelta(seconds=adjustment_seconds / 2)  #expand from start filter slightly
                new_end += timedelta(seconds=adjustment_seconds / 2)  #expand to end filter more

        else:  #fifth section
            if event.delta > 0:  #Zoom in
                new_start += timedelta(seconds=adjustment_seconds)  #shrink from filter
            else:  #Zoom out
                new_start -= timedelta(seconds=adjustment_seconds)  #expand from filter

        #ensure new start and end do not exceed the overall date range
        new_start = max(new_start, first_datetime)
        new_end = min(new_end, last_datetime)

        #update filter start and end
        self.filter_start = new_start
        self.filter_end = new_end

        #update the filter labels to reflect the new range
        self.current_filter_label.config(text=f"{self.filter_start.strftime('%Y-%m-%d %H:%M:%S')} : {self.filter_end.strftime('%Y-%m-%d %H:%M:%S')}")

        #redraw the canvas with the new filters by calling the render function
        self.append_canvas()
##########################################################################

    #just re-calls the append_canvas button.
    def refresh(self):
        self.append_canvas()

#################  Filter functions  ######################################

    #this func is used to open a window to allow the user to select a custom date range.
    def open_filter_window(self):
        #open a new window with calendars to select the date range for filtering.
        top = tk.Toplevel(self)
        #name the new window as the below title
        top.title("Filter Dates")

        #create the two caldener boxed to select dates for both the start and end filters
        tk.Label(top, text="From Date:").grid(row=0, column=0, padx=10, pady=10)
        from_calendar = Calendar(top, selectmode='day')
        from_calendar.grid(row=0, column=1, padx=10, pady=10)

        tk.Label(top, text="To Date:").grid(row=1, column=0, padx=10, pady=10)
        to_calendar = Calendar(top, selectmode='day')
        to_calendar.grid(row=1, column=1, padx=10, pady=10)

        #func to take selected dates and set the filters before re-rendering the timeline
        def apply_filter():

            #apply the selected date range filter and close the window.
            try:
                self.filter_start = from_calendar.selection_get()
                self.filter_end = to_calendar.selection_get()

                if self.filter_start and self.filter_end:
                    self.filter_start = datetime.combine(self.filter_start, datetime.min.time())
                    self.filter_end = datetime.combine(self.filter_end, datetime.max.time())

                    if self.filter_start > self.filter_end:
                        messagebox.showerror("Error", "From date must be before To date.")
                        return
                    
                    #update the current filter label with selected dates to improve clarity
                    self.current_filter_label.config(text=f"{self.filter_start.strftime('%Y-%m-%d %H:%M:%S')} - {self.filter_end.strftime('%Y-%m-%d %H:%M:%S')}")

                self.append_canvas()
                #destroy top window with filter box
                top.destroy()
            except Exception as e:
                messagebox.showerror("Error", f"An error occurred: {str(e)}")

        #button which applys the filters when pressed
        tk.Button(top, text="Apply Filter", command=apply_filter).grid(row=2, column=0, columnspan=2, pady=10)

    def clear_filter(self):
        #clear the date filter and show all incidents.
        self.filter_start = None
        self.filter_end = None
        self.current_filter_label.config(text="N/A")  #changes the filter label to N/A

        self.append_canvas()

    ########################################  First Gen Technique  ########################
    def append_canvas(self, event=None):
        #clear previous canvas drawing
        self.timeline_canvas.delete('all')

        current_width = self.timeline_canvas.winfo_width()
        current_height = self.timeline_canvas.winfo_height()

        if current_width > 0:
            self.line_size = current_width - 200  #width of timeline excluding padding

        vertical_position = current_height / 3  #timeline positioning

        #determine which data to display, check wheather evidence is being filtered by type
        if self.filter_start and self.filter_end:
            filtered_timeline = [
                (dt, notes, extra)
                for dt, notes, extra in (filtered_evidence_tuple if had_ev_been_filtered else self.timeline_list)
                if self.filter_start <= dt <= self.filter_end
            ]
        else:
            filtered_timeline = filtered_evidence_tuple if had_ev_been_filtered else self.timeline_list

        filtered_timeline.sort(key=lambda x: x[0])

        if not filtered_timeline:
            messagebox.showinfo("Filter Result", "No incidents found in this date range.")
            return

        first_datetime = filtered_timeline[0][0]
        last_datetime = filtered_timeline[-1][0]
        total_seconds = (last_datetime - first_datetime).total_seconds()

        segment_size = self.line_size / num_segments
        incident_count_per_segment = [0] * num_segments
        incidents_in_segment = [[] for _ in range(num_segments)]

        #allocate incidents to segments
        for dt, notes, extra in filtered_timeline:
            x = (dt - first_datetime).total_seconds() / total_seconds * self.line_size if total_seconds > 0 else 0
            segment_index = min(int(x // segment_size), num_segments - 1)
            incident_count_per_segment[segment_index] += 1
            incidents_in_segment[segment_index].append((dt, notes, extra))

        #draw segment, create segment with color depending on how much incidents are there.
        for i in range(num_segments):
            x_start = 50 + i * segment_size
            x_end = 50 + (i + 1) * segment_size
            incident_count = incident_count_per_segment[i]
            color = get_heatmap_colour(incident_count)
            self.timeline_canvas.create_rectangle(x_start, vertical_position - 10, x_end, vertical_position + 10, fill=color, outline=color)

        #labels for start & end datetimes
        self.timeline_canvas.create_text(30, vertical_position, text=first_datetime.strftime('%Y-%m-%d\n%H:%M:%S'), anchor='e', fill='black')
        self.timeline_canvas.create_text(50 + self.line_size + 20, vertical_position, text=last_datetime.strftime('%Y-%m-%d\n%H:%M:%S'), anchor='w', fill='black')

        label_offset = 15
        vertical_position_offset = 5
        vertical_spacing = 30 #used to use for alternative approach

        #separate paddings and counters for singles & clusters
        single_padding = 40
        cluster_padding = 80  #starts larger for clusters
        single_counter = 0
        cluster_counter = 0

        single_toggle = True
        cluster_toggle = True

        for i in range(num_segments):
            incidents = incidents_in_segment[i]

            if len(incidents) <= 4 or clustersEnabled == False:
                #draw individual incidents
                for dt, notes, extra in incidents:
                    x = (dt - first_datetime).total_seconds() / total_seconds * self.line_size if total_seconds > 0 else 0
                    base_y = vertical_position - vertical_position_offset - single_padding if single_toggle else vertical_position + vertical_position_offset + single_padding
                    label_anchor = 's' if single_toggle else 'n'

                    line = self.timeline_canvas.create_line(50 + x, base_y + 20, 50 + x, vertical_position, fill=return_color(extra), width=1)
                    dot_radius = 2
                    dot = self.timeline_canvas.create_oval(50 + x - dot_radius, vertical_position - dot_radius, 50 + x + dot_radius, vertical_position + dot_radius, fill=return_color(extra), outline=return_color(extra))
                    self.timeline_canvas.tag_bind(dot, "<Enter>", partial(self.show_temp_details, d=notes, e=extra))
                    self.timeline_canvas.tag_bind(line, "<Enter>", partial(self.show_temp_details, d=notes, e=extra))
                    self.timeline_canvas.tag_bind(line, "<Button-1>", lambda event, d=dt, n=notes: self.show_incident_details(d, n, extra))

                    single_toggle = not single_toggle
                    single_counter += 1
                    single_padding += 20  #increase after each incident

                    if single_counter >= 4:
                        single_padding = 40  #reset after 4 incidents
                        single_counter = 0

            else:
                #draw clustered incidents
                start_date = incidents[0][0]
                end_date = incidents[-1][0]
                cluster_x = (start_date - first_datetime).total_seconds() / total_seconds * self.line_size if total_seconds > 0 else 0
                base_y = vertical_position - vertical_position_offset - cluster_padding if cluster_toggle else vertical_position + vertical_position_offset + cluster_padding
                label_anchor = 's' if cluster_toggle else 'n'

                cluster_label_text = f"{start_date.strftime('%Y-%m-%d')}\n{start_date.strftime('%H:%M:%S')}\n{end_date.strftime('%Y-%m-%d')}\n{end_date.strftime('%H:%M:%S')}"
                cluster_label = tk.Label(self.timeline_canvas, text=cluster_label_text, bg='lightgray', cursor="hand2")
                cluster_label.bind("<Button-1>", lambda event, segment_incidents=incidents: self.set_cluster_time_line(segment_incidents))
                self.timeline_canvas.create_window((50 + cluster_x, base_y + label_offset), window=cluster_label, anchor=label_anchor)

                self.timeline_canvas.create_line(50 + cluster_x, vertical_position, 50 + cluster_x, base_y + 20, fill='blue', dash=(2, 2), width=0.5)
                dot_radius = 4
                self.timeline_canvas.create_oval(50 + cluster_x - dot_radius, vertical_position - dot_radius, 50 + cluster_x + dot_radius, vertical_position + dot_radius, fill='blue', outline='blue')

                cluster_toggle = not cluster_toggle
                cluster_counter += 1
                cluster_padding += 30  #increase after each

                if cluster_counter >= 4:
                    cluster_padding = 80  #reset after 4
                    cluster_counter = 0

        self.timeline_canvas.config(scrollregion=self.timeline_canvas.bbox("all"))




##########################################################################################


    def show_temp_details(self, event, d, e):
        """Displays a temporary popup with incident details when hovering over a dot."""
        
        #print(f"hover detected on event: {e}, note: {d}")  #debugging

        #destroy any existing popup to prevent duplicates and reduces clusterness
        if hasattr(self, "temp_filter_ev_type_box") and self.temp_filter_ev_type_box:
            self.temp_filter_ev_type_box.destroy()

        #create the temporary filter_ev_type_box
        self.temp_filter_ev_type_box = tk.Toplevel(self.timeline_canvas)
        self.temp_filter_ev_type_box.overrideredirect(True)  #remove filter_ev_type_box decorations
        self.temp_filter_ev_type_box.attributes("-topmost", True)  #keep on top

        #get screen width and cursor position
        screen_width = self.timeline_canvas.winfo_screenwidth()
        cursor_x = event.x_root
        cursor_y = event.y_root

        #determine placement: right by default - left if it appears of screen
        box_width = 320  #estimated
        margin = 10

        if cursor_x + box_width > screen_width:
            x = cursor_x - box_width - margin  #position the box to the left
        else:
            x = cursor_x + margin  #position the box to the right

        y = cursor_y + margin
        self.temp_filter_ev_type_box.geometry(f"+{x}+{y}")

        #create a label with styling for pop up
        label = tk.Label(
            self.temp_filter_ev_type_box, 
            text=d, 
            bg="lightgray", 
            padx=10, pady=10, 
            relief="solid", 
            borderwidth=1, 
            wraplength=300,  #adjust wrap to fit content if needed
            justify="left"
        )
        label.pack()

        #ensure the filter_ev_type_box closes when the mouse leaves the dot by calling destroy
        self.temp_filter_ev_type_box.bind("<Leave>", lambda e: self.temp_filter_ev_type_box.destroy())

        #bind the mouse leave event to the canvas.
        self.timeline_canvas.bind("<Motion>", self.check_mouse_exit)



    def check_mouse_exit(self, event):
        if hasattr(self, "temp_filter_ev_type_box") and self.temp_filter_ev_type_box:
            widget_under_cursor = self.timeline_canvas.winfo_containing(event.x_root, event.y_root)
            if widget_under_cursor is None or widget_under_cursor != self.timeline_canvas:
                self.temp_filter_ev_type_box.after(100, self.temp_filter_ev_type_box.destroy)  #add small delay to prevent it dissapearing randomly



        #close popup when the mouse leaves using the functioing
        self.temp_window.bind("<Leave>", lambda e: self.temp_window.destroy())

        #keep window on top
        self.temp_window.attributes("-topmost", True)

    #func to display details for each incident in a new window
    def show_cluster_details(self, incidents):
        cluster_window = tk.Toplevel(self)
        cluster_window.title("Cluster Incident Details")

        #add a text widget to display the details
        details_text = tk.Text(cluster_window, wrap='word', height=20, width=50)
        details_text.pack(expand=True, fill='both')

        #loop through incidents and append details to the text widget
        for dt, notes, extra in incidents:
            details_text.insert(tk.END, f"Date: {dt.strftime('%Y-%m-%d %H:%M:%S')}\nDetails:\n {notes}\n\n")

        details_text.config(state=tk.DISABLED)  #disable editing of the text
        tk.Button(cluster_window, text="Close", command=cluster_window.destroy).pack(pady=10)

    #func to create new timeline with clustered incidents
    def set_cluster_time_line(self, incidents):
        if not incidents:
            return  #exit if no incident exsit

        #extract all timestamps from incidents
        dates = [dt for dt, _, extra in incidents]

        #check if all timestamps are identical
        if all(dt == dates[0] for dt in dates):
            self.show_cluster_details(incidents)  #show detail page if times are identical 
        else:
            #update filters with the earliest and latest timestamps
            self.filter_start = min(dates)
            self.filter_end = max(dates)

            #refresh the timeline with new filters
            self.current_filter_label.config(text=f"{self.filter_start.strftime('%Y-%m-%d %H:%M:%S')} : {self.filter_end.strftime('%Y-%m-%d %H:%M:%S')}")
            self.append_canvas()

    def show_incident_details(self, dt, notes, extra):
        """Show incident details in a new window."""
        detail_window = tk.Toplevel(self)  #create a new top-level window
        detail_window.title("Incident Details")

        #create labels for date and notes
        tk.Label(detail_window, text=f"Date: {dt.strftime('%Y-%m-%d %H:%M:%S')}", font=('Arial', 12)).pack(pady=10)
        tk.Label(detail_window, text=f"{notes}", wraplength=300, justify="left").pack(pady=10)

        #add a close button
        tk.Button(detail_window, text="Close", command=detail_window.destroy).pack(pady=10)


    #Get the multiplier to change the amount the zoom is
    def get_multiplier(self):
        global global_multiplier 
        global_multiplier = set_multi(self)
        #print("set: " + str(global_multiplier)) #why is 0.00001 = to 1e****? - see user manual

    def change_segment_size(self, event):
            global num_segments 
            print(f"Key pressed: {event.keysym}")
            if event.keysym == "plus":
                print("Increasing segment size")
                if num_segments >= 125:
                    num_segments = 125
                else: num_segments += 5
            elif event.keysym == "minus":
                if num_segments <= 20:
                    num_segments = 20
                else:
                    num_segments -= 5
                print("Decreasing segment size")
            self.append_canvas()

    #################  Filter functions - for evidence type ######################################
    def enable_disable_cluster(self):
        global clustersEnabled
        if clustersEnabled == True:
            clustersEnabled = False
        else:
            clustersEnabled = True
        self.append_canvas()

    def select_filter_evidence(self):
        print("filtering evidence.")

        #create a new window
        filter_ev_type_box = tk.Toplevel()
        filter_ev_type_box.title("Select evidence to filter")

        #list of evidence types - will be exspanded to allow different datasheets
        evidence_types = ["bookmarks", "webcookies", "emails", "programs", "installedprograms", 
                        "recentdocuments", "shellbags", "usbattached", "webdownloads", "webhistories"]

        #dictionary to store check box bool variable
        ev_type_vars = {}

        #create checkboxes from evidence type
        for idx, evidence in enumerate(evidence_types):
            var = tk.BooleanVar(value=evidence_type.get(evidence, False))
            chk = tk.Checkbutton(filter_ev_type_box, text=evidence, variable=var)
            chk.grid(row=idx, column=0, sticky="w", padx=10, pady=5)
            ev_type_vars[evidence] = var  #store value

        #function to handle submission
        def submit():
            global evidence_type  #modify the global dictionary
            evidence_type.clear()  #clear previous selections

            #update dictionary with selected checkboxes
            for evidence, var in ev_type_vars.items():
                if var.get():
                    evidence_type[evidence] = True  #store as True

            if not evidence_type:
                messagebox.showwarning("Warning", "Please select at least one evidence type.")
                return

            print("Selected Evidence:", evidence_type)  #debugging output
            filter_ev_type_box.destroy()  #close the window


        def adjust_filter_list_based_on_evidence(self):
        #self.timeline_list holds tuples with (date, notes, evidence type)
            global filtered_evidence_tuple  #list to store filtered evidence
            global evidence_type  #dictionary with evidence types as keys and True as values - did not need ket pairs,
            global had_ev_been_filtered  #flag to track if filtering occurred

        #clear previous filtered_evidence
            filtered_evidence_tuple.clear()
        #iterate through timeline_list
            for entry in self.timeline_list:
                if entry[2] in evidence_type and evidence_type[entry[2]]:  #check if evidence type exists and is True
                    filtered_evidence_tuple.append(entry)
                
            print("filtered_evidence list:", filtered_evidence_tuple) 
            had_ev_been_filtered = True  #keep as is

        #submit button
        submit_btn = tk.Button(filter_ev_type_box, text="Submit", command=submit)
        submit_btn.grid(row=len(evidence_types), column=0, pady=10)

        filter_ev_type_box.wait_window()  #wait for window to close
        #print(evidence_type)
        adjust_filter_list_based_on_evidence(self)
        self.append_canvas()
        #call function here to re-adjust filter list.


##############################################

#run everything in main loop
if __name__ == "__main__":
    app = Timeline()
    app.mainloop()
