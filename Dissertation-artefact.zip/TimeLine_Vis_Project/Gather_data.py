import pandas as pd
from typing import List
from Evidence_Class import OsInfo, Bookmark, WebCookie, EmailMessage, ProgramData, AccountEmails, DataStorageUsed, InstalledPrograms, RecentDocuments, EXIFMetadata, ShellBags, USBAttachedDevice, WebDownloads, WebHistory

#function :/
#could improve on redundancy and could've created a fucntion to format date/time, reducing replicated code to get the clean date. (removing GMT)

def update_os_info_from_excel(os_info: OsInfo, file_path: str, sheet_name: str = "Operating System Information", row_index: int = 1) -> None:
    
    #update an existing OsInfo instance with data extracted from an Excel file or alternative data depending on what is wanted.
    
    #parameter os_info: An instance of OsInfo that will be updated.
    #param file_path: path to the excel file.
    #param sheet_name: name of the sheet containing the data
    #param row_index: row number - index starting from 0 where data starts.
    #load the excel sheet

    df = pd.read_excel(file_path, sheet_name=sheet_name, header=None)
    df = df.fillna('')  #replace NaN values with an empty string

    if sheet_name == "Operating System Information":
        #extract OS info from the specified row
        row_data = df.iloc[row_index]

        #update the OsInfo instance with data from the row
        os_info.processor_architecture = row_data[0]
        os_info.operating_system_name = row_data[1]
        os_info.install_date = row_data[2]
        os_info.name = row_data[3]
        os_info.owner = row_data[4]
        os_info.path = row_data[5]
        os_info.product_id = row_data[6]
        os_info.temporary_files_directory = row_data[7]
        os_info.source_file = row_data[8]
        os_info.tags = row_data[9]

def update_bookmarks_from_excel(bookmarks: List[Bookmark], file_path: str, sheet_name: str = "Web Bookmarks", row_index: int = 1) -> None:
    #same parameters
    #read the excel file, using row_index as the header row
    df = pd.read_excel(file_path, sheet_name=sheet_name, header=row_index - 1)
    df = df.fillna('')  #replace NaN values with an empty string
    
    #strip any accidental spaces from column names
    df.columns = df.columns.str.strip()
        
    #iterate over the rows in the dataframe and populate the bookmarks list
    for _, row in df.iterrows():
        #create a new bookmark instance for each row, using the data from the excel file
        bookmark = Bookmark(
            url=row.get('URL', ''),
            title=row.get('Title', ''),
            date_created=row.get('Date Created', ''),
            program=row.get('Program', ''),
            domain=row.get('Domain', ''),
            source_file=row.get('Source File', ''),
            tags=row.get('Tags', '')
        )
        
        #append the new bookmark to the list, do not add bookmarks with same URL or date created, does not help but could indicate automation - should add something to identify multiple entries
        if not any(existing_bookmark.url == bookmark.url and existing_bookmark.date_created == bookmark.date_created for existing_bookmark in bookmarks):
        
            bookmarks.append(bookmark)


def update_WebCookie_from_excel(webcookies: List[WebCookie], file_path:str, sheet_name:str = "Web Bookmarks", row_index: int =1) -> None:
    """
    Update the list of web cookies from data exstracted from the excel spreadsheet.
    :params
    webcookie = a list of web cookies
    file path = a path to the excel file
    sheet name = the name of the sheet in the excel file
    row index = the row where the actual data starts
    """

    #read the data
    df = pd.read_excel(file_path, sheet_name=sheet_name, header=row_index -1)
    df = df.fillna("") #fills na with null value

    #strip spaces from data
    df.columns = df.columns.str.strip()

    for _, row in df.iterrows():
        webcookie = WebCookie(
                url = row.get("URL", ""),
                date_time = row.get("Date/Time", ""),
                name = row.get("Name", ""),
                value = row.get("Value", ""),
                program = row.get("Program", ""),
                date_created = row.get("Date Created", ""),
                domain = row.get("Domain", ""),
                source_file = row.get("Source File", ""),
                tags = row.get("Tags", "")
         )

        webcookies.append(webcookie)

    #print(webcookies)

def update_email_from_excel(emails: List[EmailMessage], file_path:str, sheet_name:str = "E-Mail Messages", row_index: int =1) -> None:
    """Similar to previous functions with the same paramaters"""

    #read the data
    df = pd.read_excel(file_path, sheet_name=sheet_name, header=row_index -1)
    df = df.fillna("") #fills na with null value

    #strip spaces from data
    df.columns = df.columns.str.strip()

    for idx, row in df.iterrows():
        email = EmailMessage(
            email_to=row.get("E-Mail To", ""),
            email_from=row.get("E-Mail From", ""),
            subject=row.get("Subject", ""),
            date_sent=row.get("Date Sent", ""),
            date_received=row.get("Date Received", ""),
            path=row.get("Path", ""),
            email_cc=row.get("E-Mail CC", ""),
            email_bcc=row.get("E-Mail BCC", ""),
            message_id=row.get("MessageID", ""),
            has_attachment=row.get("Has Attachments", ""),
            header=row.get("Headers", ""),
            message=row.get("Message (Plaintext)", ""),
            message_attachment=row.get("Message Attachmeents", ""),
            thread_id=row.get("Thread ID", ""),
            tags=row.get("Tags", "")
        )
        emails.append(email)
    #print(emails)

def update_programData_from_excel(programs: List[ProgramData], file_path:str, sheet_name:str = "Run Programs", row_index: int =1) -> None:
    """Similar to previous functions with the same paramaters"""

    #read the data
    df = pd.read_excel(file_path, sheet_name=sheet_name, header=row_index -1)
    df = df.fillna("") #fills na with null value

    #strip spaces from data
    df.columns = df.columns.str.strip()

    #programs.clear()

    for idx, row in df.iterrows():
        pro = ProgramData(
            program=row.get("Program", ""),
            associated_artifact=row.get("Associated Artifact", ""),
            date_time=row.get("Date/Time", ""),
            count=row.get("Count", ""),
            comment=row.get("Comment", ""),
            path=row.get("Path", ""),
            tags=row.get("Tags", "")

        )
        programs.append(pro)
    #print(programs)


def update_accountEmails(emailaccounts: List[AccountEmails], file_path:str, sheet_name:str="Accounts_ Email", row_index:int=1) -> None:
    """Similar to previous functions"""

    df = pd.read_excel(file_path, sheet_name=sheet_name, header=row_index -1)
    df = df.fillna("")

    df.columns = df.columns.str.strip()

    for idx, row in df.iterrows():
        acc = AccountEmails(
            review_status=row.get("Review Status", ""),
            email_id=row.get("ID", ""),
            tags=row.get("Tags", "")
        )
        emailaccounts.append(acc)
    #print(emailaccounts)
    #no need to use this information for timeline as no date is included
    #NIU
    #data could be used on incident detail page

def update_dataStrorageUsed(dataStroages: List[DataStorageUsed], file_path:str, sheet_name:str="Data Source Usage", row_index:int=1) -> None:
    """Similar to previous functions"""

    df = pd.read_excel(file_path, sheet_name=sheet_name, header=row_index -1)
    df = df.fillna("")

    df.columns = df.columns.str.strip()

    for idx, row in df.iterrows():
        Storage = DataStorageUsed(
            description=row.get("Description", ""),
            source_file=row.get("Source File", ""),
            tags=row.get("Tags", "")
        )
        dataStroages.append(Storage)
    #print(dataStroages)
    #no need to use this information for timeline as no date is included
    #NIU
    #same issue
 

def update_installedPrograms_from_excel(installedProgram: List[InstalledPrograms], file_path:str, sheet_name:str="Installed Programs", row_index:int=1) -> None:
    """Similar to previous functions"""

    df = pd.read_excel(file_path, sheet_name=sheet_name, header=row_index -1)
    df = df.fillna("")

    df.columns = df.columns.str.strip()

    for idx, row in df.iterrows():
        pro = InstalledPrograms(
            program_name=row.get("Program Name", ""),
            installed_datetime=row.get("Install Date/Time", ""),
            source_file=row.get("Source File", ""),
            tags=row.get("Tags", "")
        )
        installedProgram.append(pro)
    #print(installedProgram)


def update_recentDocuments_from_excel(document: List[RecentDocuments], file_path:str, sheet_name:str="Recent Documents", row_index:int=1) -> None:
    """Similar to previous functions"""

    df = pd.read_excel(file_path, sheet_name=sheet_name, header=row_index -1)
    df = df.fillna("")
    
    df.columns = df.columns.str.strip()

    for idx, row in df.iterrows():
        doc = RecentDocuments(
            path=row.get("Path", ""),
            datetime=row.get("Date/Time", ""),
            comment=row.get("Comment", ""),
            name=row.get("Name", ""),
            program_name=row.get("Program Name", ""),
            value=row.get("Value", ""),
            source_file=row.get("Source File", ""),
            tags=row.get("Tags", "")
        )

        document.append(doc)
    #print(document)


##the data from this function could be further used but is currently not in use
def update_exifData(exif: List[EXIFMetadata], file_path:str, sheet_name:str="EXIF Metadata", row_index:int=1) -> None:
    """this is similar to previous functions but is not used as no date or time, could be used
    for later dev involving details around the incident"""

    df = pd.read_excel(file_path, sheet_name=sheet_name, header=row_index -1)
    df = df.fillna("")

    #ISSUE some dates refer to BST and GMT need to consider this in fruture dev on EXIFMetadata
    df.columns = df.columns.str.strip()

    for idx, row in df.iterrows():
        exifdata = EXIFMetadata(
            date_taken=row.get("Date Taken", ""),
            device_manufacturer=row.get("Device Manufacturer", ""),
            device_model=row.get("Device Model", ""),
            latitude=row.get("Latitude", ""),
            longitude=row.get("Longitude", ""),
            altitude=row.get("Altitude", ""),
            source_file=row.get("Source File", ""),
            tags=row.get("Tags", "")
        )
        exif.append(exifdata)
    #NIU


#below follows the same structure

def update_shellBags_from_excel(shbg: List[ShellBags], file_path:str, sheet_name:str="Shell Bags", row_index:int=1)-> None:

    df = pd.read_excel(file_path, sheet_name=sheet_name, header=row_index -1)
    df = df.fillna("")

    df.columns = df.columns.str.strip()

    for idx, row in df.iterrows():
        shellbag = ShellBags(
            date_accessed=row.get("Date Accessed", ""),
            date_created=row.get("Date Created",""),
            date_modified=row.get("Date Modified", ""),
            key=row.get("Key", ""),
            last_write=row.get("Last Write", ""),
            path=row.get("Path", ""),
            source_file=row.get("Source File", ""),
            tags=row.get("Tags", "")
        )
        shbg.append(shellbag)
        

def update_usb_attached_from_excel(usb:list[USBAttachedDevice], file_path:str, sheet_name:str="USB Device Attached", row_index:int=1)-> None:
    df = pd.read_excel(file_path, sheet_name=sheet_name, header=row_index -1)
    df = df.fillna("")

    df.columns = df.columns.str.strip()

    for idx, row in df.iterrows():
        usb_device = USBAttachedDevice(
            device_make=row.get("Device Make", ""),
            device_model=row.get("Device Model", ""),
            device_id=row.get("Device ID", ""),
            datetime=row.get("Date/Time", ""),
            source_file=row.get("Source File", ""),
            tags=row.get("Tags", "")
        )
        usb.append(usb_device)

def update_web_downloads_from_excel(webdownload:list[WebDownloads], file_path:str, sheet_name:str="Web Downloads", row_index:int=1)-> None:
    df = pd.read_excel(file_path, sheet_name=sheet_name, header=row_index -1)
    df = df.fillna("")

    df.columns = df.columns.str.strip()

    for idx, row in df.iterrows():
        download = WebDownloads(
            destination=row.get("Destination", ""),
            source_url=row.get("Source URL", ""),
            date_accessed=row.get("Date Accessed", ""),
            program=row.get("Program",""),
            comment=row.get("Comment", ""),
            domain=row.get("Domain", ""),
            source_file=row.get("Source File", ""),
            tags=row.get("Tags")
        )
        webdownload.append(download)


def update_web_history_from_excel(webhistory:list[WebHistory], file_path:str, sheet_name:str="Web History", row_index:int=1)->None:
    df = pd.read_excel(file_path, sheet_name=sheet_name, header=row_index -1)
    df = df.fillna("")

    df.columns = df.columns.str.strip()

    for idx, row in df.iterrows():
        history = WebHistory(
            url=row.get("URL", ""),
            date_accessed=row.get("Date Accessed", ""),
            referrer=row.get("Referrer", "",),
            title=row.get("Title"),
            program=row.get("Program", ""),
            url_domain=row.get("URL Domain", ""),
            domain=row.get("Domain", ""),
            username=row.get("Username", ""),
            source_file=row.get("Source File", ""),
            tags=row.get("Tags", "")
        )
        webhistory.append(history)

