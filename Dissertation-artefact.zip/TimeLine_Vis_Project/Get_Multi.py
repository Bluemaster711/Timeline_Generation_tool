import tkinter as tk
from tkinter import messagebox

def set_multi(app):
    #creates a gui for the user to select a multiplier from multiple options.
    #returns the corresponding float value upon selection.
    def submit():
        nonlocal multiplier
        selected_option = var.get()
        multiplier = options[selected_option]  #get the corresponding float value
        input_window.destroy()

    multiplier = None
    options = {
        "Microscopic": 0.0001,
        "Weak": 0.001,
        "Medium": 0.01,
        "Strong": 0.1,
        "Whole": 1
    }

    input_window = tk.Toplevel(app)
    input_window.title("Select Multiplier")

    label = tk.Label(input_window, text="Select a multiplier:")
    label.pack(pady=10)

    var = tk.StringVar(value="Medium")  #default selection
    for option in options.keys():
        tk.Radiobutton(input_window, text=option, variable=var, value=option).pack(anchor="w")

    submit_button = tk.Button(input_window, text="Submit", command=submit)
    submit_button.pack(pady=10)

    input_window.wait_window()  #wait until the window is closed
    return multiplier
