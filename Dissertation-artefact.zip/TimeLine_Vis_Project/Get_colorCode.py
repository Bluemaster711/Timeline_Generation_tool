

def return_color(string):

    if string == "bookmarks" : return "darkblue"
    if string == "webcookies" : return "darkblue"
    if string == "emails": return "red"
    if string == "recentdocuments" : return "orange"
    if string == "programs" : return "#009E73"
    if string == "installedprograms" : return "#009E73"
    if string == "shellbags" : return "black"
    if string == "usbattached" : return "purple"
    if string == "webdownloads" : return "darkblue"
    if string == "webhistories" : return "darkblue" 
    else:
        return "gray"

