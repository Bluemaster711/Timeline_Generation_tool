def get_heatmap_colour(count):
    
    """Determine color based on incident count."""
    #define color stops for incident counts 0, 1, 2, 4, 6, 10, 12+
    if count == 0:
        return '#99FF33'  #light green
    elif count == 1:
        return '#00FF00'  #green
    elif count in (2, 3):
        return '#FFFF00'  #yellow
    elif count in (4, 5):
        return '#FFCC00'  #orange/yellowish
    elif count in (6, 7, 8):
        return '#FF9900'  #orange
    elif count in (9, 10, 11):
        return '#FF6600'  #dark orange
    elif count >= 12:
        return '#FF0000'  #red = high density
        #return a default color if the count doesn't match exact stops
    return '#33FF33'  #default green for other numbers