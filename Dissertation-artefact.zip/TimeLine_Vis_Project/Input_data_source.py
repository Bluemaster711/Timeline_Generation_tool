import tkinter as tk
from tkinter import simpledialog
from datetime import datetime, timedelta
from tkinter import messagebox
from datetime import datetime
from tkcalendar import Calendar

from Evidence_Class import OsInfo
from Gather_data import update_os_info_from_excel, update_bookmarks_from_excel, update_WebCookie_from_excel, update_email_from_excel, update_programData_from_excel,update_installedPrograms_from_excel,update_accountEmails, update_dataStrorageUsed, update_recentDocuments_from_excel, update_exifData, update_shellBags_from_excel, update_usb_attached_from_excel,update_web_downloads_from_excel,update_web_history_from_excel


#file_path = r'C:\Users\cvdon\Documents\Uni Work\Year 4\DIssertation - Python\JD.xlsx'


def input_datasource(self, os_info, bookmarks, webcookies, emailmessages, programs, installedprograms, recentdocuments, shellbags, usbattached, webdownloads, webhistories, file_path):

    #goes through calling each function to exstract data from datasheet.
    update_os_info_from_excel(os_info, file_path, "Operating System Information")

    update_bookmarks_from_excel(bookmarks, file_path, "Web Bookmarks")


    update_WebCookie_from_excel(webcookies, file_path, "Web Cookies")


    update_email_from_excel(emailmessages, file_path, "E-Mail Messages")


    update_programData_from_excel(programs=programs, file_path=file_path, sheet_name="Run Programs")


    update_installedPrograms_from_excel(installedProgram=installedprograms, file_path=file_path, sheet_name="Installed Programs")

    update_recentDocuments_from_excel(recentdocuments, file_path, "Recent Documents")

    update_shellBags_from_excel(shellbags, file_path, "Shell Bags")

    update_usb_attached_from_excel(usb=usbattached, file_path=file_path, sheet_name="USB Device Attached")

    update_web_downloads_from_excel(webdownload=webdownloads, file_path=file_path, sheet_name="Web Downloads")

    update_web_history_from_excel(webhistory=webhistories, file_path=file_path, sheet_name="Web History")

    #different CSV files exports could contain different data sheets.

    #iterate through each list of evidence and process them, appending them to the timeline list.
    #process Bookmarks
    for bookmark in bookmarks:
        try:
            if bookmark.date_created:
                clean_date = bookmark.date_created.replace(" GMT", "")
                bookmark_datetime = datetime.strptime(clean_date, "%Y-%m-%d %H:%M:%S")
                #create a string which contains the note of the evidence
                ns = f"A bookmark for: {bookmark.url} was created at: {bookmark_datetime}"

                #then add the data to the tuple
                bookmark_tuple = (bookmark_datetime, ns, 'bookmarks')

                if bookmark_tuple not in self.timeline_list:
                    self.timeline_list.append(bookmark_tuple)
                else:
                    continue
                    #print(f"Duplicate bookmark found: {bookmark.url} at {bookmark_datetime}")
            else:
                continue
                #print(f"Warning: Bookmark has an empty 'date_created' field. Skipping.")
        except ValueError:
            continue

    #process web cookies
    for webcookie in webcookies:
        try:
            if webcookie.date_created:
                clean_date = webcookie.date_created.replace(" GMT", "")
                webcookie_datetime = datetime.strptime(clean_date, "%Y-%m-%d %H:%M:%S")

                ns = f"A cookie from: {webcookie.url} was created at: {webcookie_datetime}\n"
                ns += f"Value of cookie is: {webcookie.value}"
                
                # Add source tag to track 'webcookies'
                webcookie_tuple = (webcookie_datetime, ns, 'webcookies')

                if webcookie_tuple not in self.timeline_list:
                    self.timeline_list.append(webcookie_tuple)
                else:
                    continue
                    #print(f"Duplicate webcookie found: {webcookie.url} at {webcookie_datetime}")
            else:
                continue
                #print(f"Warning: WebCookie has an empty 'date_created' field. Skipping.")
        except ValueError:
            continue

    #process Emails
    for email in emailmessages:
        try:
            if email.date_sent:
                clean_date = email.date_sent.replace(" GMT", "")
                email_datetime = datetime.strptime(clean_date, "%Y-%m-%d %H:%M:%S")

                ns = f"A email from {email.email_from} was sent to {email.email_to}\n"
                ns += f"The email was sent at: {email_datetime}\n"
                ns += f"Email subject: {email.subject}\n"
                #ns += f"Email message: {email.message}"
                
                #add source tag to track email evidence
                email_tuple = (email_datetime, ns, 'emails')

                self.timeline_list.append(email_tuple)
            else:
                continue
                #print(f"Warning: Email has a null datetime and thus skipped.")
        except ValueError:
            continue

    #process programs
    for program in programs:
        try:
            if program.date_time:
                clean_date = program.date_time.replace(" GMT", "")
                program_datetime = datetime.strptime(clean_date, "%Y-%m-%d %H:%M:%S")
                
                program_tuple = (program_datetime, f"Program: {program.program} Ran at: {program_datetime}", 'programs')

                self.timeline_list.append(program_tuple)
            else:
                continue
                #print(f"Warning: Program has a null run datetime.")
        except ValueError:
            continue

    #process installed programs
    for program in installedprograms:
        try:
            if program.installed_datetime:
                clean_date = program.installed_datetime.replace(" GMT", "")
                program_datetime = datetime.strptime(clean_date, "%Y-%m-%d %H:%M:%S")
                
                installed_program_tuple = (program_datetime, f"Program: {program.program_name} installed at: {program_datetime}", 'installedprograms')

                self.timeline_list.append(installed_program_tuple)
            else:
                continue
                #print("Warning: Installed program has null install datetime.")
        except ValueError:
            continue

    #process recent documents
    for doc in recentdocuments:
        try:
            if doc.datetime:
                clean_date = doc.datetime.replace(" GMT", "")
                doc_datetime = datetime.strptime(clean_date, "%Y-%m-%d %H:%M:%S")

                #avoid adding date if the datetime is "0000-00-00 00:00:00" cannot use null values
                if doc_datetime != datetime(1, 1, 1):
                    ns = f"Document: {doc.source_file} last modified at: {doc_datetime}"

                    doc_tuple = (doc_datetime, ns, 'recentdocuments')

                    self.timeline_list.append(doc_tuple)
                else:
                    continue
                    #print(f"Skipping document with invalid date: {doc.source_file}")
            else:
                continue
                #print("Warning: Document has null datetime.")
        except ValueError:
            continue

    #process shellbags
    for shell in shellbags:
        try:
            #initialize the date variables to avoid inputting incorrect values
            shell_date_accessed = None
            shell_date_created = None
            shell_date_modified = None
            shell_date_last_write = None

            #check if any valid date exists and use that date.
            if shell.date_accessed or shell.date_created or shell.date_modified or shell.last_write:
                #parse each possible date field to ensure all feilds are valid
                if shell.date_accessed:
                    clean_date = shell.date_accessed.replace(" GMT", "")
                    shell_date_accessed = datetime.strptime(clean_date, "%Y-%m-%d %H:%M:%S")

                if shell.date_created:
                    clean_date = shell.date_created.replace(" GMT", "")
                    shell_date_created = datetime.strptime(clean_date, "%Y-%m-%d %H:%M:%S")

                if shell.date_modified:
                    clean_date = shell.date_modified.replace(" GMT", "")
                    shell_date_modified = datetime.strptime(clean_date, "%Y-%m-%d %H:%M:%S")

                if shell.last_write:
                    clean_date = shell.last_write.replace(" GMT", "")
                    shell_date_last_write = datetime.strptime(clean_date, "%Y-%m-%d %H:%M:%S")

                #prepare the notes
                ns = f"Reg Key: {shell.key} details are:\n"
                ns += f"Date Created: {shell_date_created}\n" if shell_date_created else ""
                ns += f"Date Accessed: {shell_date_accessed}\n" if shell_date_accessed else ""
                ns += f"Date Modified: {shell_date_modified}\n" if shell_date_modified else ""
                ns += f"Last Write: {shell_date_last_write}" if shell_date_last_write else ""

                #add the correct date to the list based on the first valid date
                if shell_date_created:
                    self.timeline_list.append((shell_date_created, ns, 'shellbags'))
                elif shell_date_modified:
                    self.timeline_list.append((shell_date_modified, ns, 'shellbags'))
                elif shell_date_accessed:
                    self.timeline_list.append((shell_date_accessed, ns, 'shellbags'))
                elif shell_date_last_write:
                    self.timeline_list.append((shell_date_last_write, ns, 'shellbags'))
            else:
                continue
                #print("Warning: Shellbag contains no valid date.")
        except ValueError:
            continue
    

    for device in usbattached:
        try:
            if device.datetime:
                clean_date = device.datetime.replace(" GMT", "")
                device_datetime = datetime.strptime(clean_date, "%Y-%m-%d %H:%M:%S")

                if device_datetime != datetime(1, 1, 1):
                    ns = f"USB device: {device.device_id}, attached at: {device_datetime}\n"
                    ns += f"Device Make: {device.device_make}, Model: {device.device_model}"
                    device_tuple = (device_datetime, ns, 'usbattached')

                    self.timeline_list.append(device_tuple)
                else:
                    continue
                    #print(f"Skipping document with invalid date: {doc.source_file}")
            else:
                continue
                #print("Warning: Document has null datetime.")
        except ValueError:
            continue

    for webdown in webdownloads:
        try:
            #check if any dates are present
            if webdown.date_accessed:
                clean_date = webdown.date_accessed.replace(" GMT", "")
                webdown_datetime = datetime.strptime(clean_date, "%Y-%m-%d %H:%M:%S")

                #prevent null datetimes
                if webdown_datetime != datetime(1,1,1):
                    ns = f"File downloaded from: {webdown.source_url} and saved at: {webdown.destination}\n"
                    ns += f"File downloaded at: {webdown_datetime} \n"
                    ns += f"comment: {webdown.comment}"

                    webdown_tuple = (webdown_datetime, ns, 'webdownloads')
                    self.timeline_list.append(webdown_tuple)
                else:
                    continue
        except ValueError:
            continue

    for hist in webhistories:
        try:
            if hist.date_accessed:
                clean_date = hist.date_accessed.replace(" GMT", "")
                hist_datetime = datetime.strptime(clean_date, "%Y-%m-%d %H:%M:%S")

                if hist_datetime != datetime(1,1,1):
                    ns = f"Website {hist.url}\nWas accessed at {hist_datetime}\n"
                    ns += f"The program: {hist.program} was used by {hist.username} to access URL"

                    hist_tuple = (hist_datetime, ns, 'webhistories')
                    self.timeline_list.append(hist_tuple)
                else:
                    continue
        except ValueError:
            continue

    